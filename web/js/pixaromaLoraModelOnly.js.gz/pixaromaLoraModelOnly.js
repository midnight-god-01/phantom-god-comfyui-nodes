import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

const CLASS = "PixaromaLoraModelOnly";
const STATE_KEY = "pixaromaLoraModelOnlyState";
const DEFAULTS_KEY = "PhantomGod.LoraModelOnly.Defaults";
const BRAND = "#f66744";
const MAX_ROWS = 64;
const BASE_STATE = {
  loras: [],
  step: 0.05,
  defStrength: 1,
  hideExt: true,
  cacheMode: "last",
  accent: BRAND,
};

const CSS = `
.pg-ll-root{box-sizing:border-box;width:100%;padding:9px;background:#1d1d1d;color:#ddd;border-radius:5px;font:11px ui-sans-serif,system-ui,sans-serif}
.pg-ll-band{display:flex;flex-direction:column;gap:5px;margin-bottom:9px}
.pg-ll-add{height:29px;border:0;border-radius:6px;background:var(--pg-accent);color:white;font-weight:650;cursor:pointer}
.pg-ll-add:disabled{opacity:.45;cursor:default}
.pg-ll-top{display:flex;gap:6px;height:26px}
.pg-ll-all,.pg-ll-gear{border:1px solid #444;border-radius:5px;background:#292929;color:#bbb;cursor:pointer}
.pg-ll-all{flex:1;text-align:left;padding:0 9px}
.pg-ll-gear{width:34px}
.pg-ll-list{display:flex;flex-direction:column;gap:6px}
.pg-ll-row{height:33px;box-sizing:border-box;display:flex;align-items:center;gap:6px;padding:0 6px;border:1px solid #393939;border-radius:6px;background:#262626}
.pg-ll-row.off{opacity:.42}
.pg-ll-name{flex:1;min-width:0;height:25px;text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;background:#161616;border:1px solid #3a3a3a;border-radius:5px;color:#ddd;padding:0 8px;font:11px monospace;cursor:pointer}
.pg-ll-name.empty{color:#777}
.pg-ll-name.missing{color:#e06565;border-color:#a44}
.pg-ll-strength{width:65px;height:25px;box-sizing:border-box;background:#161616;border:1px solid #3a3a3a;border-radius:5px;color:#fff;text-align:center;font:11px monospace}
.pg-ll-info,.pg-ll-toggle{flex:none;width:23px;height:23px;border:1px solid #444;border-radius:5px;background:#303030;color:#bbb;cursor:pointer}
.pg-ll-toggle{width:30px;height:16px;border-radius:99px;position:relative;padding:0}
.pg-ll-toggle:after{content:"";position:absolute;top:1px;left:1px;width:12px;height:12px;border-radius:50%;background:#888}
.pg-ll-toggle.on{background:var(--pg-accent)}
.pg-ll-toggle.on:after{left:15px;background:white}
.pg-ll-empty{height:46px;display:grid;place-items:center;border:1px dashed #414141;border-radius:6px;color:#777}
.pg-ll-popup{position:fixed;z-index:10030;width:300px;max-width:calc(100vw - 16px);max-height:min(440px,70vh);display:flex;flex-direction:column;background:#262626;color:#ddd;border:1px solid var(--pg-accent);border-radius:9px;box-shadow:0 12px 36px #000b;overflow:hidden;font:12px system-ui}
.pg-ll-popup input{margin:9px;padding:8px;background:#171717;border:1px solid #444;border-radius:5px;color:white}
.pg-ll-options{overflow:auto;padding:0 7px 8px}
.pg-ll-option{padding:7px 8px;cursor:pointer;overflow-wrap:anywhere;border-radius:4px}
.pg-ll-option:hover{background:#3b3b3b}
.pg-ll-panel{position:fixed;z-index:10031;width:min(350px,92vw);max-height:75vh;overflow:auto;background:#292929;color:#ddd;border:1px solid var(--pg-accent);border-radius:9px;box-shadow:0 12px 36px #000b;font:12px system-ui}
.pg-ll-panel header{padding:12px;border-bottom:1px solid #444;font-weight:650}
.pg-ll-section{padding:11px 12px;border-bottom:1px solid #3b3b3b}
.pg-ll-meta{color:#999;font:10px monospace;line-height:1.7}
.pg-ll-panel button{cursor:pointer;transition:background .14s ease,border-color .14s ease,color .14s ease}
.pg-ll-panel input[type=number],.pg-ll-panel select{display:block;width:100%;height:32px;box-sizing:border-box;margin-top:4px;padding:0 9px;border:1px solid #484848;border-radius:5px;background-color:#171717;color:#e3e3e3;font:12px ui-sans-serif,system-ui,sans-serif;outline:none}
.pg-ll-panel input[type=number]:focus,.pg-ll-panel select:focus{border-color:var(--pg-accent);box-shadow:0 0 0 1px color-mix(in srgb,var(--pg-accent) 35%,transparent)}
.pg-ll-panel select{padding-right:30px;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath d='m2.5 4.5 3.5 3 3.5-3' fill='none' stroke='%23bcbcbc' stroke-width='1.4' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 9px center}
.pg-ll-panel select option{background:#242424;color:#e3e3e3}
.pg-ll-panel input[type=checkbox]{width:14px;height:14px;margin:0;accent-color:var(--pg-accent)}
.pg-ll-panel input[type=color]{width:42px;height:27px;padding:2px;border:1px solid #555;border-radius:5px;background:#171717;cursor:pointer}
.pg-ll-panel footer{display:flex;gap:7px;padding:10px}
.pg-ll-panel footer button{flex:1;min-height:32px;padding:6px 10px;border:1px solid #555;border-radius:6px;background:#333;color:#ddd;font:600 11px ui-sans-serif,system-ui,sans-serif}
.pg-ll-panel footer button:hover{background:#3c3c3c;border-color:#707070}
.pg-ll-panel footer .primary{background:var(--pg-accent);border-color:var(--pg-accent);color:white}
.pg-ll-panel footer .primary:hover{filter:brightness(1.08)}
.pg-ll-menu{position:fixed;z-index:10032;min-width:150px;padding:5px;background:#292929;border:1px solid #555;border-radius:7px;box-shadow:0 10px 30px #000b;font:12px system-ui;color:#ddd}
.pg-ll-menu button{display:block;width:100%;padding:7px 9px;text-align:left;background:transparent;border:0;border-radius:4px;color:inherit;cursor:pointer}
.pg-ll-menu button:hover{background:#414141}
.pg-ll-menu button.danger{color:#e28a7d}
`;

if (!document.getElementById("pg-lora-css")) {
  const style = document.createElement("style");
  style.id = "pg-lora-css";
  style.textContent = CSS;
  document.head.append(style);
}

const session = { files: null, popup: null, panel: null, menu: null };
const clone = value => JSON.parse(JSON.stringify(value));
const makeId = () => globalThis.crypto?.randomUUID?.() || `r${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`;

function clampStrength(value) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(-100, Math.min(100, Math.round(number * 100) / 100)) : 0;
}

function normalizeState(raw) {
  const state = { ...clone(BASE_STATE), ...(raw && typeof raw === "object" ? raw : {}) };
  state.loras = (Array.isArray(state.loras) ? state.loras : []).slice(0, MAX_ROWS)
    .filter(row => row && typeof row === "object")
    .map(row => ({
      id: typeof row.id === "string" && row.id ? row.id : makeId(),
      name: typeof row.name === "string" ? row.name : "",
      on: row.on !== false,
      strength: clampStrength(row.strength ?? state.defStrength),
    }));
  state.step = Number.isFinite(Number(state.step)) && Number(state.step) > 0 ? Number(state.step) : 0.05;
  state.defStrength = clampStrength(state.defStrength);
  state.hideExt = state.hideExt !== false;
  state.cacheMode = ["all", "none"].includes(state.cacheMode) ? state.cacheMode : "last";
  state.accent = /^#[0-9a-f]{6}$/i.test(state.accent || "") ? state.accent : BRAND;
  return state;
}

function readState(node) {
  const saved = node.properties?.[STATE_KEY];
  if (typeof saved === "string") {
    try { return normalizeState(JSON.parse(saved)); } catch { /* use defaults */ }
  }
  try {
    const defaults = app.ui?.settings?.getSettingValue(DEFAULTS_KEY);
    return normalizeState(typeof defaults === "string" ? JSON.parse(defaults) : defaults);
  } catch {
    return normalizeState(null);
  }
}

function syncStateWidget(node) {
  const widget = node.widgets?.find(item => item.name === "lora_state");
  if (!widget) return false;

  widget.options ||= {};
  // Keep this ordinary STRING widget in prompt serialization, but hide it on
  // both Classic LiteGraph and Nodes 2.0 surfaces. The visible UI is the DOM widget.
  widget.hidden = true;
  widget.serialize = true;
  widget.options.hidden = true;
  widget.options.serialize = true;
  widget.computeSize = () => [0, -4];
  widget.value = JSON.stringify(promptState(readState(node)));
  return true;
}

function writeState(node, rawState) {
  node.properties ||= {};
  node.properties[STATE_KEY] = JSON.stringify(normalizeState(rawState));
  syncStateWidget(node);
  node.graph?.change?.();
  return readState(node);
}

// Cosmetic values are excluded. Row values and cache mode are serialized into
// the hidden STRING widget used to apply the stack during prompt execution.
function promptState(state) {
  return {
    cacheMode: state.cacheMode,
    loras: state.loras.map(row => ({
      name: row.name,
      on: row.on,
      strength: row.strength,
    })),
  };
}

function canvasRect(node) {
  const canvas = app.canvasOrUndefined || app.canvas;
  if (!canvas || !node?.pos || !node?.size) return null;
  const scale = canvas.ds?.scale || 1;
  const offset = canvas.ds?.offset || [0, 0];
  return {
    left: node.pos[0] * scale + offset[0],
    top: node.pos[1] * scale + offset[1],
    width: node.size[0] * scale,
    height: node.size[1] * scale,
  };
}

function placePopup(element, node, anchor) {
  const rect = anchor?.getBoundingClientRect?.() || canvasRect(node);
  const width = element.offsetWidth || 310;
  const height = element.offsetHeight || 280;
  const pad = 8;
  let left = rect ? rect.right ?? rect.left + rect.width + 10 : (innerWidth - width) / 2;
  let top = rect ? (rect.bottom ?? rect.top) + 6 : (innerHeight - height) / 2;
  if (left + width > innerWidth - pad) left = rect ? Math.max(pad, rect.left - width - 10) : left;
  element.style.left = `${Math.max(pad, Math.min(left, innerWidth - width - pad))}px`;
  element.style.top = `${Math.max(pad, Math.min(top, innerHeight - height - pad))}px`;
}

function closePopups() {
  for (const key of ["popup", "panel", "menu"]) {
    session[key]?.remove();
    session[key] = null;
  }
}

async function listLoras(force = false) {
  if (session.files && !force) return session.files;
  const response = await api.fetchApi("/models/loras");
  if (!response.ok) throw new Error(`Could not list LoRAs (${response.status}).`);
  const values = await response.json();
  if (!Array.isArray(values)) throw new Error("ComfyUI returned an invalid LoRA list.");
  session.files = values.filter(value => typeof value === "string").sort((a, b) => a.localeCompare(b));
  return session.files;
}

function displayName(name, hideExtension = true) {
  const base = String(name || "").split(/[\\/]/).pop();
  return hideExtension ? base.replace(/\.(safetensors|safetensor|ckpt|pt|pth|bin|sft)$/i, "") : base;
}

function rowById(node, rowId) {
  return readState(node).loras.find(row => row.id === rowId);
}

function isGraphLoading(node) {
  const activeGraph = app.canvasOrUndefined?.graph;
  return Boolean(app.configuringGraph || node?.graph?.status?.loading || activeGraph?.status?.loading);
}

function refreshNode(node, structural = false) {
  renderNode(node);
  node.graph?.change?.();
  node.setDirtyCanvas?.(true, true);
  if (structural && !isGraphLoading(node)) {
    queueMicrotask(() => fitNode(node));
  }
}

function fitNode(node) {
  const width = Math.max(318, Number(node.size?.[0]) || 318);
  let height;
  try { height = node.computeSize?.()[1]; } catch { /* use fallback */ }
  height = Number.isFinite(height) && height > 0
    ? height
    : (readState(node).loras.length ? 90 + readState(node).loras.length * 39 : 133);
  if (typeof node.setSize === "function") node.setSize([width, height]);
  else node.size = [width, height];
}

function openPicker(node, rowId, anchor) {
  closePopups();
  const popup = document.createElement("div");
  popup.className = "pg-ll-popup";
  popup.style.setProperty("--pg-accent", readState(node).accent);
  const search = document.createElement("input");
  search.placeholder = "Search LoRAs…";
  const options = document.createElement("div");
  options.className = "pg-ll-options";
  popup.append(search, options);
  document.body.append(popup);
  session.popup = popup;

  const draw = () => {
    options.replaceChildren();
    const query = search.value.trim().toLowerCase();
    const files = (session.files || []).filter(file => file.toLowerCase().includes(query));
    for (const file of files) {
      const option = document.createElement("div");
      option.className = "pg-ll-option";
      option.textContent = file;
      option.addEventListener("click", () => {
        const state = readState(node);
        const row = state.loras.find(entry => entry.id === rowId);
        if (!row) return;
        row.name = file;
        writeState(node, state);
        refreshNode(node, true);
        closePopups();
      });
      options.append(option);
    }
    if (!files.length) {
      const empty = document.createElement("div");
      empty.className = "pg-ll-option";
      empty.textContent = session.files?.length ? "No matches." : "No LoRAs found in models/loras.";
      options.append(empty);
    }
  };

  placePopup(popup, node, anchor);
  search.addEventListener("input", draw);
  search.addEventListener("keydown", event => { if (event.key === "Escape") closePopups(); });
  draw();
  search.focus();
}

async function infoFor(name) {
  const response = await api.fetchApi(`/phantom-god/lora-info?name=${encodeURIComponent(name)}`);
  if (!response.ok) {
    let message = `Could not read metadata (${response.status}).`;
    try { message = (await response.json()).error || message; } catch { /* keep status */ }
    throw new Error(message);
  }
  const result = await response.json();
  if (!result?.ok || !result.info) throw new Error(result?.error || "No metadata was returned.");
  return result.info;
}

function openInfoPanel(node, rowId) {
  closePopups();
  const startingRow = rowById(node, rowId);
  if (!startingRow?.name) return;
  const filename = startingRow.name;
  const panel = document.createElement("div");
  panel.className = "pg-ll-panel";
  panel.style.setProperty("--pg-accent", readState(node).accent);
  const header = document.createElement("header");
  header.textContent = "LoRA information";
  const body = document.createElement("div");
  body.className = "pg-ll-section";
  body.textContent = "Reading embedded metadata…";
  const footer = document.createElement("footer");
  const done = document.createElement("button");
  done.className = "primary";
  done.textContent = "Done";
  done.onclick = closePopups;
  footer.append(done);
  panel.append(header, body, footer);
  document.body.append(panel);
  session.panel = panel;
  placePopup(panel, node);

  infoFor(filename).then(info => {
    if (session.panel !== panel || !panel.isConnected) return;

    body.replaceChildren();
    const title = document.createElement("div");
    title.style.fontWeight = "650";
    title.textContent = info.title || filename;
    const metadata = document.createElement("div");
    metadata.className = "pg-ll-meta";
    metadata.textContent = [
      info.base_model && `Base: ${info.base_model}`,
      info.rank && `Rank: ${info.rank}`,
      info.alpha && `Alpha: ${info.alpha}`,
      info.num_images && `Images: ${info.num_images}`,
      info.date && `Date: ${info.date}`,
    ].filter(Boolean).join(" · ") || "No embedded metadata found.";
    body.append(title, metadata);
  }).catch(error => {
    if (session.panel === panel && panel.isConnected) body.textContent = `Could not read LoRA metadata: ${error.message}`;
  });
}

function openRowMenu(node, rowId, event) {
  event.preventDefault();
  closePopups();
  const menu = document.createElement("div");
  menu.className = "pg-ll-menu";
  const state = readState(node);
  const index = state.loras.findIndex(row => row.id === rowId);
  if (index < 0) return;

  const addAction = (label, action, danger = false) => {
    const button = document.createElement("button");
    button.textContent = label;
    if (danger) button.className = "danger";
    button.onclick = () => { closePopups(); action(); };
    menu.append(button);
  };
  addAction("Move up", () => moveRow(node, rowId, -1));
  addAction("Move down", () => moveRow(node, rowId, 1));
  addAction("Duplicate", () => duplicateRow(node, rowId));
  addAction("Remove", () => removeRow(node, rowId), true);
  document.body.append(menu);
  session.menu = menu;
  const width = 160, height = 150, pad = 8;
  menu.style.left = `${Math.max(pad, Math.min(event.clientX, innerWidth - width - pad))}px`;
  menu.style.top = `${Math.max(pad, Math.min(event.clientY, innerHeight - height - pad))}px`;
}

function moveRow(node, rowId, direction) {
  const state = readState(node);
  const index = state.loras.findIndex(row => row.id === rowId);
  const next = index + direction;
  if (index < 0 || next < 0 || next >= state.loras.length) return;
  const [row] = state.loras.splice(index, 1);
  state.loras.splice(next, 0, row);
  writeState(node, state);
  refreshNode(node, true);
}

function duplicateRow(node, rowId) {
  const state = readState(node);
  const index = state.loras.findIndex(row => row.id === rowId);
  if (index < 0 || state.loras.length >= MAX_ROWS) return;
  const copy = { ...state.loras[index], id: makeId() };
  state.loras.splice(index + 1, 0, copy);
  writeState(node, state);
  refreshNode(node, true);
}

function removeRow(node, rowId) {
  const state = readState(node);
  const index = state.loras.findIndex(row => row.id === rowId);
  if (index < 0) return;
  state.loras.splice(index, 1);
  writeState(node, state);
  refreshNode(node, true);
}

function openSettings(node) {
  closePopups();
  const state = readState(node);
  const panel = document.createElement("div");
  panel.className = "pg-ll-panel";
  panel.style.setProperty("--pg-accent", state.accent);
  const header = document.createElement("header");
  header.textContent = "LoRA Loader settings";
  const body = document.createElement("div");
  body.className = "pg-ll-section";

  const numberField = (label, key, min, max, step) => {
    const wrapper = document.createElement("label");
    wrapper.style.cssText = "display:block;margin:9px 0";
    wrapper.textContent = label;
    const input = document.createElement("input");
    input.type = "number";
    input.min = String(min);
    input.max = String(max);
    input.step = String(step);
    input.value = String(state[key]);
    input.className = "pg-ll-field";
    input.onchange = () => {
      const next = readState(node);
      next[key] = key === "step" ? Math.max(0.001, Number(input.value) || 0.05) : clampStrength(input.value);
      writeState(node, next);
    };
    wrapper.append(input);
    body.append(wrapper);
  };
  numberField("Default model strength", "defStrength", -100, 100, 0.01);
  numberField("Strength step", "step", 0.001, 10, 0.01);

  const cacheLabel = document.createElement("label");
  cacheLabel.style.cssText = "display:block;margin:9px 0";
  cacheLabel.textContent = "LoRA memory use";
  const cache = document.createElement("select");
  for (const [value, label] of [["last", "Keep last LoRA in memory"], ["all", "Keep all LoRAs in memory"], ["none", "Do not cache LoRAs"]]) {
    const option = document.createElement("option"); option.value = value; option.textContent = label; cache.append(option);
  }
  cache.value = state.cacheMode;
  cache.setAttribute("aria-label", "LoRA memory use");
  cache.onchange = () => { const next = readState(node); next.cacheMode = cache.value; writeState(node, next); };
  cacheLabel.append(cache);
  body.append(cacheLabel);

  const hideLabel = document.createElement("label");
  hideLabel.style.cssText = "display:flex;gap:8px;align-items:center;margin:10px 0";
  const hide = document.createElement("input"); hide.type = "checkbox"; hide.checked = state.hideExt;
  hide.onchange = () => { const next = readState(node); next.hideExt = hide.checked; writeState(node, next); refreshNode(node, false); };
  hideLabel.append(hide, document.createTextNode("Hide file extensions"));
  body.append(hideLabel);

  const accentLabel = document.createElement("label");
  accentLabel.style.cssText = "display:flex;gap:8px;align-items:center;margin:10px 0";
  accentLabel.append(document.createTextNode("Highlight colour"));
  const accent = document.createElement("input"); accent.type = "color"; accent.value = state.accent;
  accent.onchange = () => { const next = readState(node); next.accent = accent.value; writeState(node, next); panel.style.setProperty("--pg-accent", accent.value); refreshNode(node, false); };
  accentLabel.append(accent);
  body.append(accentLabel);

  const footer = document.createElement("footer");
  const save = document.createElement("button"); save.className = "primary"; save.textContent = "Set as default";
  save.onclick = async () => {
    const latest = readState(node);
    const defaults = {
      defStrength: latest.defStrength,
      step: latest.step,
      hideExt: latest.hideExt,
      cacheMode: latest.cacheMode,
      accent: latest.accent,
    };
    await app.ui.settings.setSettingValueAsync(DEFAULTS_KEY, JSON.stringify(defaults));
    save.textContent = "Saved";
  };
  const done = document.createElement("button"); done.textContent = "Done"; done.onclick = closePopups;
  footer.append(save, done);
  panel.append(header, body, footer);
  document.body.append(panel);
  session.panel = panel;
  placePopup(panel, node);
}

function renderNode(node) {
  const root = node._pgLoraRoot;
  if (!root?.isConnected) return;
  const state = readState(node);
  root.replaceChildren();
  root.style.setProperty("--pg-accent", state.accent);

  const band = document.createElement("div");
  band.className = "pg-ll-band";
  const add = document.createElement("button");
  add.className = "pg-ll-add";
  add.textContent = "＋ Add LoRA";
  add.disabled = state.loras.length >= MAX_ROWS;
  add.onclick = async () => {
    const next = readState(node);
    if (next.loras.length >= MAX_ROWS) return;
    next.loras.push({ id: makeId(), name: "", on: true, strength: next.defStrength });
    writeState(node, next);
    refreshNode(node, true);
    const row = readState(node).loras.at(-1);
    try { await listLoras(true); }
    catch (error) { console.warn("[Phantom God LoRA] List refresh failed:", error); }
    if (row) {
      const button = root.querySelector(`[data-row="${row.id}"] .pg-ll-name`);
      if (button) openPicker(node, row.id, button);
    }
  };

  const top = document.createElement("div");
  top.className = "pg-ll-top";
  const all = document.createElement("button");
  all.className = "pg-ll-all";
  all.textContent = state.loras.length
    ? `${state.loras.filter(row => row.on).length} / ${state.loras.length} on`
    : "No LoRAs";
  all.title = "Turn every LoRA on or off";
  all.onclick = () => {
    const next = readState(node);
    const turnOff = next.loras.length > 0 && next.loras.every(row => row.on);
    next.loras.forEach(row => { row.on = !turnOff; });
    writeState(node, next);
    refreshNode(node, false);
  };
  const gear = document.createElement("button");
  gear.className = "pg-ll-gear";
  gear.textContent = "⚙";
  gear.title = "LoRA Loader settings";
  gear.onclick = () => openSettings(node);
  top.append(all, gear);
  band.append(add, top);
  root.append(band);

  if (!state.loras.length) {
    const empty = document.createElement("div");
    empty.className = "pg-ll-empty";
    empty.textContent = "No LoRAs yet — click ＋ Add LoRA to begin.";
    root.append(empty);
    return;
  }

  const list = document.createElement("div");
  list.className = "pg-ll-list";
  for (const row of state.loras) {
    const line = document.createElement("div");
    line.className = "pg-ll-row" + (row.on ? "" : " off");
    line.dataset.row = row.id;
    line.addEventListener("contextmenu", event => openRowMenu(node, row.id, event));

    const missing = Boolean(row.name && session.files && !session.files.includes(row.name));
    const name = document.createElement("button");
    name.className = "pg-ll-name" + (row.name ? "" : " empty") + (missing ? " missing" : "");
    name.textContent = row.name ? displayName(row.name, state.hideExt) : "(put LoRAs in models/loras)";
    name.title = missing ? `${row.name} — file not found; pick the LoRA again.` : (row.name || "Pick a LoRA");
    name.onclick = async () => {
      try {
        await listLoras(true);
        renderNode(node);
        const current = root.querySelector(`[data-row="${row.id}"] .pg-ll-name`);
        if (current) openPicker(node, row.id, current);
      } catch (error) {
        console.warn("[Phantom God LoRA] Could not list LoRAs:", error);
        name.title = error.message;
      }
    };

    const strength = document.createElement("input");
    strength.type = "number";
    strength.min = "-100";
    strength.max = "100";
    strength.step = String(state.step);
    strength.className = "pg-ll-strength";
    strength.value = row.strength.toFixed(2);
    strength.title = "Model strength";
    strength.onchange = () => {
      const next = readState(node);
      const entry = next.loras.find(item => item.id === row.id);
      if (!entry) return;
      entry.strength = clampStrength(strength.value);
      writeState(node, next);
      refreshNode(node, false);
    };

    const info = document.createElement("button");
    info.className = "pg-ll-info";
    info.textContent = "i";
    info.title = "LoRA metadata";
    info.onclick = () => openInfoPanel(node, row.id);

    const toggle = document.createElement("button");
    toggle.className = "pg-ll-toggle" + (row.on ? " on" : "");
    toggle.title = row.on ? "Turn off" : "Turn on";
    toggle.setAttribute("aria-label", toggle.title);
    toggle.onclick = () => {
      const next = readState(node);
      const entry = next.loras.find(item => item.id === row.id);
      if (entry) entry.on = !entry.on;
      writeState(node, next);
      refreshNode(node, false);
    };

    line.append(name, strength, info, toggle);
    list.append(line);
  }
  root.append(list);
}

function setupNode(node) {
  const root = document.createElement("div");
  root.className = "pg-ll-root";
  node._pgLoraRoot = root;

  const widget = node.addDOMWidget("pixaroma_lora_ui", "phantom_god_lora_loader", root, {
    serialize: false,
    margin: 4,
    getValue: () => readState(node),
    setValue: () => {},
    getMinHeight: () => {
      const count = readState(node).loras.length;
      return count ? 90 + count * 39 : 133;
    },
    getMaxHeight: () => {
      const count = readState(node).loras.length;
      return count ? 90 + count * 39 : 133;
    },
  });
  widget.options ||= {};
  syncStateWidget(node);
  try {
    Object.defineProperty(widget.options, "canvasOnly", {
      configurable: true,
      enumerable: true,
      get: () => !window.LiteGraph?.vueNodesMode,
    });
  } catch {
    widget.options.canvasOnly = !window.LiteGraph?.vueNodesMode;
  }

  node.size ||= [340, 140];
  node.size[0] = Math.max(node.size[0], 318);
  queueMicrotask(() => {
    renderNode(node);
    // Give new nodes enough room for the full DOM widget. Do not rewrite a
    // workflow's saved dimensions while ComfyUI is restoring that graph.
    if (!isGraphLoading(node)) fitNode(node);
  });
  listLoras().then(() => renderNode(node)).catch(error => {
    console.warn("[Phantom God LoRA] Initial LoRA list failed:", error);
  });
}

app.registerExtension({
  name: "PhantomGod.PixaromaLoraModelOnly",
  beforeRegisterNodeDef(nodeType, nodeData) {
    if (nodeData.name !== CLASS || nodeType.prototype._pgLoraPatched) return;
    nodeType.prototype._pgLoraPatched = true;

    const originalConfigure = nodeType.prototype.onConfigure;
    nodeType.prototype.onConfigure = function(...args) {
      const result = originalConfigure?.apply(this, args);
      syncStateWidget(this);
      if (this._pgLoraRoot) renderNode(this);
      return result;
    };

    const originalRemoved = nodeType.prototype.onRemoved;
    nodeType.prototype.onRemoved = function(...args) {
      closePopups();
      return originalRemoved?.apply(this, args);
    };
  },
  nodeCreated(node) {
    if (node.comfyClass === CLASS || node.type === CLASS) setupNode(node);
  },
});

if (!window.__pgLoraTransientListeners) {
  window.__pgLoraTransientListeners = true;
  document.addEventListener("pointerdown", event => {
    const target = event.target;
    if (!target?.closest?.(".pg-ll-popup,.pg-ll-panel,.pg-ll-menu,.pg-ll-name,.pg-ll-add,.pg-ll-info,.pg-ll-gear")) {
      closePopups();
    }
  }, true);
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") closePopups();
  }, true);
}
